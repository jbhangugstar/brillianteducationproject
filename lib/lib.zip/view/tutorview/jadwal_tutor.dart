import 'dart:io';
import 'package:flutter/material.dart';
import 'package:brillianteducationproject/controller/kelas_controller.dart';
import 'package:brillianteducationproject/models/kelas_model.dart';
import 'package:brillianteducationproject/database/preference.dart';
import 'package:brillianteducationproject/view/tutorview/manage_students_screen.dart';
import 'package:brillianteducationproject/view/tutorview/buat_kelas_baru.dart';
import 'package:brillianteducationproject/extension/navigator.dart';

class JadwalTutorScreen extends StatefulWidget {
  const JadwalTutorScreen({super.key});

  @override
  State<JadwalTutorScreen> createState() => _JadwalTutorScreenState();
}

class _JadwalTutorScreenState extends State<JadwalTutorScreen>
    with WidgetsBindingObserver {
  List<Kelas> kelasTutor = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadKelasTutor();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadKelasTutor();
    }
  }

  Future<void> _loadKelasTutor() async {
    try {
      final tutorId = await PreferenceHandler.getTutorId();

      if (tutorId == null) {
        setState(() {
          isLoading = false;
        });
        return;
      }

      final classes = await KelasController.getKelasByTutor(tutorId);

      setState(() {
        kelasTutor = classes;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _refreshClasses() async {
    await _loadKelasTutor();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F6FA),

      appBar: AppBar(
        backgroundColor: const Color(0xFFB23AEE),
        title: const Text(
          "Brilliant Education",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshClasses,
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFF6C4FD8),
        icon: const Icon(Icons.add),
        label: const Text("Kelas Baru"),
        onPressed: () {
          context.push(const BuatKelasBaruScreen()).then((_) {
            _refreshClasses();
          });
        },
      ),

      body: isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF6C4FD8)),
            )
          : RefreshIndicator(
              onRefresh: _refreshClasses,
              child: kelasTutor.isEmpty
                  ? ListView(
                      children: const [
                        SizedBox(height: 300),
                        Center(child: Text("Belum ada kelas")),
                      ],
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: kelasTutor.length,
                      itemBuilder: (context, index) {
                        final kelas = kelasTutor[index];
                        final id = kelas.id ?? 0;

                        Color statusColor;

                        switch (kelas.status?.toLowerCase()) {
                          case 'aktif':
                            statusColor = Colors.green;
                            break;
                          case 'selesai':
                            statusColor = Colors.blue;
                            break;
                          case 'batal':
                            statusColor = Colors.red;
                            break;
                          default:
                            statusColor = Colors.grey;
                        }

                        return Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.08),
                                  blurRadius: 8,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),

                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // HEADER
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF6C4FD8),
                                    borderRadius: BorderRadius.vertical(
                                      top: Radius.circular(16),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          kelas.namaKelas,
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),

                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: statusColor.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                        ),
                                        child: Text(
                                          kelas.status ?? "aktif",
                                          style: TextStyle(
                                            color: statusColor,
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                // FOTO
                                if (kelas.foto != null &&
                                    kelas.foto!.isNotEmpty)
                                  Image.file(
                                    File(kelas.foto!),
                                    height: 180,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                  ),

                                Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Rp ${kelas.harga}",
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),

                                      const SizedBox(height: 6),

                                      Text(kelas.jadwal),

                                      const SizedBox(height: 6),

                                      Text("${kelas.jumlahSiswa ?? 0} siswa"),

                                      const SizedBox(height: 12),

                                      Row(
                                        children: [
                                          // KELOLA KELAS
                                          Expanded(
                                            child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: const Color(
                                                  0xFF6C4FD8,
                                                ),
                                              ),
                                              onPressed: () {
                                                context.push(
                                                  ManageStudentsScreen(
                                                    kelasId: id,
                                                    namaKelas: kelas.namaKelas,
                                                  ),
                                                );
                                              },
                                              child: const Text(
                                                "Kelola Kelas",
                                                style: TextStyle(
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ),
                                          ),

                                          const SizedBox(width: 8),

                                          // MENU EDIT HAPUS
                                          PopupMenuButton<String>(
                                            onSelected: (value) async {
                                              if (value == "edit") {
                                                context
                                                    .push(
                                                      BuatKelasBaruScreen(
                                                        kelas: kelas,
                                                        kelasId: kelas.id,
                                                      ),
                                                    )
                                                    .then(
                                                      (_) => _refreshClasses(),
                                                    );
                                              }

                                              if (value == "delete") {
                                                if (kelas.id != null) {
                                                  await KelasController.deleteKelas(
                                                    kelas.id!,
                                                  );

                                                  ScaffoldMessenger.of(
                                                    context,
                                                  ).showSnackBar(
                                                    const SnackBar(
                                                      content: Text(
                                                        "Kelas berhasil dihapus",
                                                      ),
                                                    ),
                                                  );

                                                  _refreshClasses();
                                                }
                                              }
                                            },

                                            itemBuilder: (context) => const [
                                              PopupMenuItem(
                                                value: "edit",
                                                child: Text("Edit"),
                                              ),
                                              PopupMenuItem(
                                                value: "delete",
                                                child: Text("Hapus"),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
    );
  }
}
